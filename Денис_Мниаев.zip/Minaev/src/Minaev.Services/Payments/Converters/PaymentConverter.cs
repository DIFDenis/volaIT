﻿namespace Minaev.Services.Payments.Converters;

public static class PaymentConverter
{
}
