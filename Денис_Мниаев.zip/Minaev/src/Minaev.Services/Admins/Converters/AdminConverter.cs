﻿namespace Minaev.Services.Admins.Converters;

public static class AdminConverter
{
}
