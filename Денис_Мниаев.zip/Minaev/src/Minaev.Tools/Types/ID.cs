﻿namespace Minaev.Tools.Types;

public record ID(Int64 Value)
{
    public static implicit operator ID(Int64 id) => new(id);
    public static implicit operator Int64(ID id) => id.Value;
    public static implicit operator ID(String id) => new(Convert.ToInt64(id));

    public static ID New()
    {
        Random rnd = new();
        return rnd.NextInt64(1, Int64.MaxValue);
    }

    public static ID Robot()
    {
        return 1_000_000_000_000_000_000;
    }
}