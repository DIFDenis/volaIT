﻿namespace Minaev.Domain.Accounts;

public class AccountBlank
{
    public String Username { get; set; }
    public String Password { get; set; }
    public Boolean IsAdmin { get; set; }
    public Double Balance { get; set; }
}

