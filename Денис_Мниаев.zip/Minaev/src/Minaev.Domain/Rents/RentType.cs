﻿namespace Minaev.Domain.Rents;

public enum RentType
{
    Minutes = 1,
    Days = 2
}