﻿namespace Minaev.WebAPI.Infrastructure;

[AttributeUsage(AttributeTargets.Method)]
public class AllowAnonymousAttribute : Attribute
{ }