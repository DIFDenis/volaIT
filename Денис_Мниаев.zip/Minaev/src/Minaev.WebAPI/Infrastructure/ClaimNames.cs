﻿namespace Minaev.WebAPI.Infrastructure;

public static class ClaimNames
{
    public static readonly String Id = "Value";
    public static readonly String IsAdmin = "IsAdmin";
}